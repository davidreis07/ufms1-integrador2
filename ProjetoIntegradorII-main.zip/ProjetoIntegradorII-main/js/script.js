// Script básico para interatividade (caso necessário)
document.addEventListener("DOMContentLoaded", function() {
    console.log("Página carregada com sucesso!");
    // Adicionar outras funcionalidades interativas conforme necessário
});
